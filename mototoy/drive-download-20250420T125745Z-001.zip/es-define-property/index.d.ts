declare const defineProperty: false | typeof Object.defineProperty;

export = defineProperty;