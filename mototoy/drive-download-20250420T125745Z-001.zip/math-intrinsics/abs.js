'use strict';

/** @type {import('./abs')} */
module.exports = Math.abs;
