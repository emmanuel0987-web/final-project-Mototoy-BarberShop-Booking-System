'use strict';

/** @type {import('./floor')} */
module.exports = Math.floor;
