import {BigInteger} from '../';

console.log(typeof BigInteger)
